package com.xcx.shop.filter;

import javax.servlet.*;
import java.io.IOException;

/**
 * @title: FilterTest
 * @description: 过滤器
 * @date: 2021/1/28
 * @author: stuil
 * @copyright: Copyright (c) 2020
 * @version: 1.0
 */

public class FilterTest implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {

    }

    @Override
    public void destroy() {

    }
}
